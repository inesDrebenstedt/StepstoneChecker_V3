package com.jobchecker._aux;

/*
 * Under construction
 */
public class PageSniffer {
	
	private int pageNum;
	private int pageIndex = pageNum - 1;
	
	

}
