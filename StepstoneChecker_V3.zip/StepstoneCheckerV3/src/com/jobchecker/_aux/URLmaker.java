package com.jobchecker._aux;

/**
* Placeholder class.
* Copy/paste the resulting URL of your
* specific stepstone job search and 
* keep it as a public static variable.
*/
public class URLmaker {
	
/*
 * Here, three different job search params
 * stored as url(x).
 * Go to stepstone.de, type in your keywords
 * set your filters, hit "search"
 * then copy paste resulting URL as static variable.
 */
	public static String url1 = "https://tinyurl.com/f4zy5ay3";
			//"https://www.stepstone.de/5/ergebnisliste.html?stf=freeText&ns=1&qs=%5B%7B%22id%22%3A%22698540%22%2C%22type%22%3A%22jd%22%2C%22description%22%3A%22Junior+Java+Entwickler%2Fin%22%7D%5D&companyID=0&cityID=0&sourceOfTheSearchField=resultlistpage%3Ageneral&searchOrigin=Resultlist_top-search&ke=Junior+Java+Entwickler%2Fin&ws=Hessen&ra=30";
	
	public static String url2 = "https://tinyurl.com/8h6yvnvm";
			//"https://www.stepstone.de/5/ergebnisliste.html?stf=freeText&ns=1&qs=%5B%7B%22id%22%3A%22223031%22%2C%22description%22%3A%22Java-Entwickler%2Fin%22%2C%22type%22%3A%22jd%22%7D%5D&companyID=0&cityID=0&sourceOfTheSearchField=homepagemex%3Ageneral&searchOrigin=Homepage_top-search&ke=Java-Entwickler%2Fin&ws=Hessen+&ra=30";
	
	public static String url3 = "https://tinyurl.com/9adrap96";
			//"https://www.stepstone.de/5/ergebnisliste.html?stf=freeText&ns=1&companyid=0&sourceofthesearchfield=homepagemex%3Ageneral&qs=%5B%7B%22id%22%3A698540%2C%22description%22%3A%22Junior%20Java%20Entwickler%5C%2Fin%22%2C%22type%22%3A%22jd%22%7D%5D&cityid=0&ke=Junior%20Java%20Entwickler%2Fin&radius=30&wt=80005&suid=bba5a92f-5939-46dc-9780-73ddfd5e95e1&action=facet_selected%3Bexperiences%3B90001&ex=90001";

}
