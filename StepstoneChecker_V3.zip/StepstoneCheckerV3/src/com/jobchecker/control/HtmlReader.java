package com.jobchecker.control;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/*
 * Gets URL and generates resulting String of HTML.
 */
public class HtmlReader {

	String link;
	String htmlJobMarker;
	String searchMarker = "";
	String readerTitle;

	public HtmlReader() {
	}

	public HtmlReader(String readerTitle, String link, String htmlJobMarker, String searchMarker) {
		this.readerTitle = readerTitle;
		this.link = link;
		this.htmlJobMarker = htmlJobMarker;
	}

	/*
	 * Gets HTML content of target URL into a string:
	 */
	public String getHTMLresult(String link) {
		URL url = null;
		Scanner sc = null;
		String result = "";
		try {
			url = new URL(link);
			try {
				// Gets content of url:
				sc = new Scanner(url.openStream());
			} catch (IOException e) {
				e.printStackTrace();
			}

			// StringBuffer for holding result:
			StringBuffer sb = new StringBuffer();
			while (sc.hasNext()) {
				sb.append(sc.next());
				// Just out of curiosity and for testing purposes:
				// System.out.println(sc.next()); 
			}
			// Puts content of stringbuffer object into string "result": 
			result = sb.toString();
			// Just out of curiosity and for testing purposes:
			// System.out.println("Content of the web page: "+ result);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public String getHtmlJobMarker() {
		return this.htmlJobMarker;
	}

	public String getReaderTitle() {
		return this.readerTitle;
	}

	public String getLink() {
		return this.link;
	}

}
