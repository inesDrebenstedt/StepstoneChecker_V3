package com.jobchecker.control;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/*
 * Class to put together some of the processing steps:
 */
public class StepstoneResultMaker {
	
	protected String htmlMarker = "job-item-title";
	protected String searchMarker = "job-item-company-name";
	
	public StepstoneResultMaker(String title, String url)
	{
		HtmlReader htmlReader = new HtmlReader(title, url, htmlMarker, searchMarker);
		//If console output only needed:
		//stepstoneResult(htmlReader.getReaderTitle(), htmlReader.getHTMLresult(htmlReader.getLink())); //then comment out fileMaker.
		FileMaker fileMaker = new FileMaker();
		fileMaker.makeFile(title, htmlReader.getHTMLresult(url));
		}
	
	/*
	 * Method for console output:
	 */
	public void stepstoneResult(String title, String result)
	{		
		String[] hitsPerSearchWithRest = result.split("at-facet-header-total-results\">");
		String[] hitsPerSearch = hitsPerSearchWithRest[1].split("</span>");

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		
		// Just out of curiosity and for testing purposes:
		//String[] resultAsArr = result.split("job-item-title");		
//		int jobCount = 0;
//		
//		for(int i = 1; i < resultAsArr.length; i++)
//		{			
//			String[] jobTitlesAsArr = resultAsArr[i].split("href=\"/stellenangebote--");
//			String[] snip2Arr = jobTitlesAsArr[1].split("inline.html");
//			//System.out.println("Step1: " + snip2Arr[0] );
//			jobCount++;
//		}
		
		System.out.println("" + hitsPerSearch[0] + " hits on " + dtf.format(now) + " for " + title);
	}
	
	
	/*
	 * Method to return fetched result as string for
	 * usage in makeFile() later on.
	 * The result string is split by stepstone-specific strings occuring 
	 * inside its HTML result source.
	 */
	public static String stepstoneResult2String(String title, String result)
	{
		String outputString = "";
		
		String[] hitsPerSearchWithRest = result.split("at-facet-header-total-results\">");
		String[] hitsPerSearch = hitsPerSearchWithRest[1].split("</span>");

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		
		outputString = "" + hitsPerSearch[0] + " hits on " + dtf.format(now) + " for " + title;
		return outputString;
	}

}
