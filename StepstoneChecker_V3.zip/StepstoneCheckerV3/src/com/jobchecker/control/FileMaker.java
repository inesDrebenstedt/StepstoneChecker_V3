package com.jobchecker.control;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/*
 * Puts # of search result items plus date into file.
 * The title of the file will resemble the string 
 * given in constructor of StepstoneResultMaker object in class Main.
 */
public class FileMaker {

	public void makeFile(String readerTitle, String result) {
		String outStr = StepstoneResultMaker.stepstoneResult2String(readerTitle, result);

		try {
			//Optional: set your specific path the replace filename with filepath:
			//String filePath = "/home/yourusername/Dokumente/nameofyoureclipseworkspace/StepstoneCheckerV3/resultsAsTxtFile/" + readerTitle + ".txt";
			File file = new File(readerTitle); //creates new file titled like search, substitute file path here
			file.setWritable(true);
			file.setReadable(true);
			BufferedWriter out = new BufferedWriter(new FileWriter(file, true));
			out.append("\n");
			out.append("\n" + outStr);
			out.close();
			
			//Shows what's been written into file via console:
			BufferedReader in = new BufferedReader(new FileReader(readerTitle));//reads file created above, substitute with file path here
			String str;

			while ((str = in.readLine()) != null) {
				System.out.println(str);
			}
			in.close();

		} catch (Exception e) {
			System.out.println("Exception occured in makeFile(): " + e );
			e.printStackTrace();
		}
	}

}
