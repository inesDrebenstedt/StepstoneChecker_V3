package com.jobchecker.main;

import com.jobchecker._aux.URLmaker;
import com.jobchecker.control.StepstoneResultMaker;

public class Main {

	public static void main(String[] args) {

		StepstoneResultMaker s1 = new StepstoneResultMaker("Stepstone Junior Java Hessen +30km",  URLmaker.url1 );
		StepstoneResultMaker s2 = new StepstoneResultMaker("Stepstone Java Hessen +30km",  URLmaker.url2 );
		StepstoneResultMaker s3 = new StepstoneResultMaker("Stepstone Junior Java bundesweit remote",  URLmaker.url3);

	
	
	}

}
